# Swagger\Client\InboundsApi

All URIs are relative to *https://api.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getDeliveryWindows**](InboundsApi.md#getDeliveryWindows) | **GET** /retailer/inbounds/delivery-windows | Get delivery windows for inbound shipments
[**getFbbTransporters**](InboundsApi.md#getFbbTransporters) | **GET** /retailer/inbounds/fbb-transporters | Get FBB transporters list
[**getInbound**](InboundsApi.md#getInbound) | **GET** /retailer/inbounds/{inbound-id} | Get inbound by inbound id
[**getInboundShippingLabel**](InboundsApi.md#getInboundShippingLabel) | **GET** /retailer/inbounds/{inbound-id}/shippinglabel | Get FBB shippinglabel by inbound id
[**getInbounds**](InboundsApi.md#getInbounds) | **GET** /retailer/inbounds | Get inbound shipment list
[**getInventory**](InboundsApi.md#getInventory) | **GET** /retailer/inventory | Get LVB/FBB inventory
[**getPackingList**](InboundsApi.md#getPackingList) | **GET** /retailer/inbounds/{inbound-id}/packinglist | Get packing list by inbound id
[**getProductLabels**](InboundsApi.md#getProductLabels) | **POST** /retailer/inbounds/productlabels | Get FBB productlabels by EAN
[**postInbound**](InboundsApi.md#postInbound) | **POST** /retailer/inbounds | Post inbound shipment


# **getDeliveryWindows**
> \Swagger\Client\Model\DeliveryWindowsForInboundShipments_ getDeliveryWindows($delivery_date, $items_to_send)

Get delivery windows for inbound shipments

Retrieve a list of available delivery windows for an inbound shipment.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$delivery_date = "Today's date."; // string | The expected delivery date for the inbound in ISO 8601 format.
$items_to_send = 1; // int | The number of items that will be sent in the inbound.

try {
    $result = $apiInstance->getDeliveryWindows($delivery_date, $items_to_send);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getDeliveryWindows: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **delivery_date** | **string**| The expected delivery date for the inbound in ISO 8601 format. | [optional] [default to Today&#39;s date.]
 **items_to_send** | **int**| The number of items that will be sent in the inbound. | [optional] [default to 1]

### Return type

[**\Swagger\Client\Model\DeliveryWindowsForInboundShipments_**](../Model/DeliveryWindowsForInboundShipments_.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getFbbTransporters**
> \Swagger\Client\Model\TransportersResponse getFbbTransporters()

Get FBB transporters list

Get FBB transporters list.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getFbbTransporters();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getFbbTransporters: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\TransportersResponse**](../Model/TransportersResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInbound**
> \Swagger\Client\Model\Inbound getInbound($inbound_id)

Get inbound by inbound id

Get inbound by inbound id.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$inbound_id = 789; // int | A unique id for an inbound shipment.

try {
    $result = $apiInstance->getInbound($inbound_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getInbound: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inbound_id** | **int**| A unique id for an inbound shipment. |

### Return type

[**\Swagger\Client\Model\Inbound**](../Model/Inbound.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInboundShippingLabel**
> string getInboundShippingLabel($inbound_id)

Get FBB shippinglabel by inbound id

Get FBB shippinglabel by inbound id.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$inbound_id = 789; // int | A unique id for an inbound shipment.

try {
    $result = $apiInstance->getInboundShippingLabel($inbound_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getInboundShippingLabel: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inbound_id** | **int**| A unique id for an inbound shipment. |

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+pdf

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInbounds**
> \Swagger\Client\Model\Inbounds getInbounds($reference, $bsku, $creation_start, $creation_end, $state, $page)

Get inbound shipment list

A List of inbound shipments.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$reference = "reference_example"; // string | A user defined reference to identify the inbound shipment with.
$bsku = "bsku_example"; // string | The BSKU number associated with this product.
$creation_start = "creation_start_example"; // string | The creation start date to find the inbound shipment in ISO 8601 format.
$creation_end = "creation_end_example"; // string | The creation end date to find the inbound shipment in ISO 8601 format.
$state = "state_example"; // string | The current state of the inbound shipment.
$page = 1; // int | The page number.

try {
    $result = $apiInstance->getInbounds($reference, $bsku, $creation_start, $creation_end, $state, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getInbounds: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **reference** | **string**| A user defined reference to identify the inbound shipment with. | [optional]
 **bsku** | **string**| The BSKU number associated with this product. | [optional]
 **creation_start** | **string**| The creation start date to find the inbound shipment in ISO 8601 format. | [optional]
 **creation_end** | **string**| The creation end date to find the inbound shipment in ISO 8601 format. | [optional]
 **state** | **string**| The current state of the inbound shipment. | [optional]
 **page** | **int**| The page number. | [optional] [default to 1]

### Return type

[**\Swagger\Client\Model\Inbounds**](../Model/Inbounds.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInventory**
> \Swagger\Client\Model\InventoryResponse getInventory($page, $quantity, $stock, $state, $query)

Get LVB/FBB inventory

The inventory endpoint is a specific LVB/FBB endpoint. It only provides information about your fulfillment by bol.com inventory. This endpoint does not provide information about your own stock.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$page = 1; // int | The page number.
$quantity = array("quantity_example"); // string[] | Filter inventory by quantity.
$stock = "stock_example"; // string | Filter inventory by stock level.
$state = "state_example"; // string | Filter inventory by NCK‘s stock level.
$query = "query_example"; // string | Filter inventory by EAN or product title.

try {
    $result = $apiInstance->getInventory($page, $quantity, $stock, $state, $query);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getInventory: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| The page number. | [optional] [default to 1]
 **quantity** | [**string[]**](../Model/string.md)| Filter inventory by quantity. | [optional]
 **stock** | **string**| Filter inventory by stock level. | [optional]
 **state** | **string**| Filter inventory by NCK‘s stock level. | [optional]
 **query** | **string**| Filter inventory by EAN or product title. | [optional]

### Return type

[**\Swagger\Client\Model\InventoryResponse**](../Model/InventoryResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPackingList**
> string getPackingList($inbound_id)

Get packing list by inbound id

Get packing list by inbound id.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$inbound_id = 789; // int | A unique id for an inbound shipment.

try {
    $result = $apiInstance->getPackingList($inbound_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getPackingList: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inbound_id** | **int**| A unique id for an inbound shipment. |

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+pdf

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getProductLabels**
> string getProductLabels($format, $product_labels_request)

Get FBB productlabels by EAN

Get FBB productlabels by EAN.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$format = "AVERY_J8159"; // string | The printer format to create labels for.
$product_labels_request = new \Swagger\Client\Model\ProductLabelsRequest(); // \Swagger\Client\Model\ProductLabelsRequest | The product labels to retrieve.

try {
    $result = $apiInstance->getProductLabels($format, $product_labels_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->getProductLabels: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| The printer format to create labels for. | [optional] [default to AVERY_J8159]
 **product_labels_request** | [**\Swagger\Client\Model\ProductLabelsRequest**](../Model/ProductLabelsRequest.md)| The product labels to retrieve. | [optional]

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+pdf

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **postInbound**
> \Swagger\Client\Model\ProcessStatus postInbound($inbound_request)

Post inbound shipment

Create a new inbound shipment.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InboundsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$inbound_request = new \Swagger\Client\Model\InboundRequest(); // \Swagger\Client\Model\InboundRequest | inboundRequest

try {
    $result = $apiInstance->postInbound($inbound_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InboundsApi->postInbound: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inbound_request** | [**\Swagger\Client\Model\InboundRequest**](../Model/InboundRequest.md)| inboundRequest |

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

