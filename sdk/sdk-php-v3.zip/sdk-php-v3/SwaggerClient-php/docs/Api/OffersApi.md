# Swagger\Client\OffersApi

All URIs are relative to *https://api.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createOfferCsvFile**](OffersApi.md#createOfferCsvFile) | **GET** /retailer/offers/export | Create offers CSV file
[**deleteOffers**](OffersApi.md#deleteOffers) | **DELETE** /retailer/offers | Delete offers in bulk
[**downloadOfferCsvFile**](OffersApi.md#downloadOfferCsvFile) | **GET** /retailer/offers/export/{filename} | Download offers CSV file.
[**getOffer**](OffersApi.md#getOffer) | **GET** /retailer/offers/{ean} | Get an offer by product EAN
[**upsertOffer**](OffersApi.md#upsertOffer) | **PUT** /retailer/offers | Create or update an offer


# **createOfferCsvFile**
> \Swagger\Client\Model\OfferFile createOfferCsvFile($filter)

Create offers CSV file

Creates a CSV file containing all offers filtered by published status. If the published status isn't provided, all offers are included. The URL to the created CSV file is returned which can be used in the call to download the CSV file.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OffersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$filter = "filter_example"; // string | Filter the returned offers by published status.

try {
    $result = $apiInstance->createOfferCsvFile($filter);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OffersApi->createOfferCsvFile: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filter** | **string**| Filter the returned offers by published status. | [optional]

### Return type

[**\Swagger\Client\Model\OfferFile**](../Model/OfferFile.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteOffers**
> deleteOffers($delete_bulk_request)

Delete offers in bulk

Delete multiple offers in a single request up to a maximum of 1000.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OffersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$delete_bulk_request = new \Swagger\Client\Model\DeleteBulkRequest(); // \Swagger\Client\Model\DeleteBulkRequest | deleteBulkRequest

try {
    $apiInstance->deleteOffers($delete_bulk_request);
} catch (Exception $e) {
    echo 'Exception when calling OffersApi->deleteOffers: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **delete_bulk_request** | [**\Swagger\Client\Model\DeleteBulkRequest**](../Model/DeleteBulkRequest.md)| deleteBulkRequest |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **downloadOfferCsvFile**
> downloadOfferCsvFile($filename)

Download offers CSV file.

The CSV file is created by calling 'Create offers CSV file'.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OffersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$filename = "filename_example"; // string | The filename of the CSV file.

try {
    $apiInstance->downloadOfferCsvFile($filename);
} catch (Exception $e) {
    echo 'Exception when calling OffersApi->downloadOfferCsvFile: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filename** | **string**| The filename of the CSV file. |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+csv

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOffer**
> \Swagger\Client\Model\OfferResponse getOffer($ean, $condition)

Get an offer by product EAN

Gets all offers for products with the given EAN. If a condition is provided, only offers for the given product EAN with that condition are returned.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OffersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$ean = "ean_example"; // string | The EAN of the product to get offers for.
$condition = "condition_example"; // string | The condition of the product to filter offers by.

try {
    $result = $apiInstance->getOffer($ean, $condition);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OffersApi->getOffer: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ean** | **string**| The EAN of the product to get offers for. |
 **condition** | **string**| The condition of the product to filter offers by. | [optional]

### Return type

[**\Swagger\Client\Model\OfferResponse**](../Model/OfferResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **upsertOffer**
> upsertOffer($upsert_request)

Create or update an offer

Offers are uniquely identified by the combination of EAN and condition. When inserting an EAN and condition combination that is already known as an offer, this request will result in an update for that offer. When inserting an EAN and condition combination that is not yet known as an offer, it will result in a newly created offer.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OffersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$upsert_request = new \Swagger\Client\Model\UpsertRequest(); // \Swagger\Client\Model\UpsertRequest | upsertRequest

try {
    $apiInstance->upsertOffer($upsert_request);
} catch (Exception $e) {
    echo 'Exception when calling OffersApi->upsertOffer: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **upsert_request** | [**\Swagger\Client\Model\UpsertRequest**](../Model/UpsertRequest.md)| upsertRequest |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

