# Cancellation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date_time** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format when the article was cancelled. | 
**reason_code** | **string** | The code representing the reason for cancellation. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


