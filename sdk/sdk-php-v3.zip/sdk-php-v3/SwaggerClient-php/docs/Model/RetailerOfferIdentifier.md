# RetailerOfferIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | **string** | Condition of the offer. It is possible to have more conditions per EAN, this means one EAN can be linked to multiple offers. Please choose the EAN and condition combination you wish to delete. Note: if you do not specify a condition, all conditions for this EAN will be deleted. | 
**ean** | **string** | EAN number associated with this offer. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


