# Transport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipping_label_id** | **int** | The shipping label id. | [optional] 
**track_and_trace** | **string** | The track and trace code associated with this transport. The entered track and trace code will be verified. If you do not have the code, please omit this attribute entirely. | 
**transport_id** | **int** | The transport id. | 
**transporter_code** | **string** | Specify the transporter used to fulfil this shipment. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


