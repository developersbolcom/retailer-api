# Reduction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cost_reduction** | **float** | Amount the will be deducted from the commission fee if the maximum price criteria is met. | 
**end_date** | [**\DateTime**](\DateTime.md) | Date at which time this commission reduction will end. | 
**maximum_price** | **float** | Maximum offer price that can be used to still benefit from a commission reduction. | 
**start_date** | [**\DateTime**](\DateTime.md) | Date from which time this commission reduction is applicable. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


