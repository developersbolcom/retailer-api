# UpsertRetailerOffer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | **string** | The condition of the offer. It is possible to have more conditions per EAN. | 
**delivery_code** | **string** | The delivery promise that applies to this product. | 
**description** | **string** | A description that is only applicable when the chosen condition is unequal to “NEW”. Note: it will be ignored if condition is NEW. Attention: Maximum amount of characters: 2000. | [optional] 
**ean** | **string** | The EAN number associated with this product. | 
**fulfilment_method** | **string** | Specifies whether this shipment has been fulfilled by the retailer (FBR) or fulfilled by bol.com (FBB). | [optional] 
**price** | **double** | The price of the product with a period as a decimal separator. | [optional] 
**publish** | **bool** | Boolean (true/false) determining whether the seller desires the product to be offered for sale on the bol.com website. Note: even when set to true, other factors may cause the offer not to be online. | [optional] 
**quantity_in_stock** | **int** | The amount of items in stock. Minimum value: 0. Maximum value: 999. | [optional] 
**reference_code** | **string** | A value that may help you identify this particular offer when receiving orders. This element can optionally be left empty. Attention: Maximum amount of characters: 20. | [optional] 
**title** | **string** | Title of the product as shown on the bol.com webshop. When the EAN is unknown at bol.com, your input will be shown. However, the bol.com title will be shown when it entails a known EAN. Attention: Maximum amount of characters: 500. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


