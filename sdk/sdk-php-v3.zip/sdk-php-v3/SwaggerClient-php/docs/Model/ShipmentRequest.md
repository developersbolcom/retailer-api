# ShipmentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipment_reference** | **string** | Used for administration purposes. | [optional] 
**shipping_label_code** | **string** | Specifies shipping label to be used for this shipment. Can be retrieved through the shipping label endpoint. | [optional] 
**transport** | [**\Swagger\Client\Model\Transport**](Transport.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


