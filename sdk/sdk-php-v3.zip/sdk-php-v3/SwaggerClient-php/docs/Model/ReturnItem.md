# ReturnItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer_details** | [**\Swagger\Client\Model\CustomerDetails**](CustomerDetails.md) |  | [optional] 
**ean** | **string** | The EAN number associated with this product. | 
**fulfilment_method** | **string** | Specifies whether this shipment has been fulfilled by the retailer (FBR) or fulfilled by bol.com (FBB). | 
**handled** | **bool** | Boolean (true/false) determining whether the return was handled. | 
**handling_result** | **string** | The handling result requested by the user. | [optional] 
**order_id** | **int** | The order id. | 
**processing_date_time** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format when the return was processed. | [optional] 
**processing_result** | **string** | The processing result of the return. | [optional] 
**quantity** | **int** | Amount of the product being ordered. | 
**registration_date_time** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format of registration. | 
**return_number** | **int** | Specifies which return item is being handled. | 
**return_reason** | **string** | Return reason category. | 
**return_reason_comments** | **string** | Additional comments about the return. | 
**title** | **string** | The product title. | 
**track_and_trace** | **string** | The track and trace code associated with this transport. The entered track and trace code will be verified. If you do not have the code, please omit this attribute entirely. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


