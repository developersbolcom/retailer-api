# InventoryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offers** | [**\Swagger\Client\Model\InventoryOffer[]**](InventoryOffer.md) |  | 
**total_count** | **int** | The total amount of unique numbers. | 
**total_page_count** | **int** | The total amount of available pages with offers. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


