# CustomerDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_supplement** | **string** | The address supplement. | 
**city** | **string** | The city name. | 
**company** | **string** | The company name. | 
**country_code** | **string** | The country code. | 
**delivery_phone_number** | **string** | The delivery phone number. | 
**email** | **string** | The e-mail address. | 
**extra_address_information** | **string** | Extra information about the address. | 
**first_name** | **string** | The first name. | 
**house_number** | **string** | The house number. | 
**house_number_extended** | **string** | The extension on house number. | 
**salutation_code** | **string** | The salutation code. | 
**street_name** | **string** | The street name. | 
**surname** | **string** | The surname. | 
**vat_number** | **string** | The VAT number. | 
**zip_code** | **string** | The ZIP code. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


