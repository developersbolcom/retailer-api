# ProcessStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_timestamp** | [**\DateTime**](\DateTime.md) | Time of creation of the response. | 
**description** | **string** | Describes the action that is being processed. | 
**entity_id** | **string** | The id of the object being processed. E.g. in case of a shipment process id, you will receive the id of the order item being processed. | [optional] 
**error_message** | **string** | Shows error message if applicable. | [optional] 
**event_type** | **string** | Name of the requested action that is being processed. | 
**id** | **int** | The process status id. | [optional] 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) | Lists available actions applicable to this endpoint. | 
**seller_id** | **int** | The seller id. | 
**status** | **string** | Status of the action being processed. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


