# Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer_details** | [**\Swagger\Client\Model\CustomerDetails**](CustomerDetails.md) |  | 
**shipment_date** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format when the order item was shipped. | 
**shipment_id** | **int** | The shipment id. | 
**shipment_items** | [**\Swagger\Client\Model\ShipmentItem[]**](ShipmentItem.md) |  | 
**shipment_reference** | **string** | Used for administration purposes. | 
**transport** | [**\Swagger\Client\Model\Transport**](Transport.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


