<?php
use kamermans\OAuth2\GrantType\ClientCredentials;
use kamermans\OAuth2\GrantType\RefreshToken;
use kamermans\OAuth2\OAuth2Middleware;
use GuzzleHttp\HandlerStack;

require_once('./vendor/autoload.php');

function setupClientCredentialsApiClient($client_id = "", $client_secret = "") {
    $reauth_client  = new GuzzleHttp\Client([
        'base_uri' => 'https://login.bol.com/token',
    ]);

    $reauth_config = [
        "client_id" => $client_id,
        "client_secret" => $client_secret
    ];

    $grant_type = new ClientCredentials($reauth_client , $reauth_config);
    $refresh_grant_type = new RefreshToken($reauth_client, $reauth_config);
    $oauth = new OAuth2Middleware($grant_type, $refresh_grant_type);

    $stack = HandlerStack::create();
    $stack->push($oauth);


    $client = new GuzzleHttp\Client([
        'handler' => $stack,
        'auth' => 'oauth',
    ]);

    return $client;
}
?>