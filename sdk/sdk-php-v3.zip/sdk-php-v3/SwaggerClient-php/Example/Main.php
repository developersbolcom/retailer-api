<?php
include_once('./lib/Api/OrdersApi.php');
include_once('./lib/Oauth2/OauthApiClient.php');

$clientCredentialsApiClient = setupClientCredentialsApiClient("",          "");

//Example to get orders.
$ordersApi = new \Swagger\Client\Api\OrdersApi($clientCredentialsApiClient);

try {
    $orders = ($ordersApi->getOrders(1, "FBB"));
} catch (\Swagger\Client\ApiException $e) {
    print $e;
}

print $orders;
?>