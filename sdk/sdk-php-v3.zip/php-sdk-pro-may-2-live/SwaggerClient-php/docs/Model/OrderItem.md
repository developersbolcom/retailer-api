# OrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cancel_request** | **bool** | True or False. True only if the consumer has cancelled the order before the seller has shipped it. | 
**ean** | **string** | EAN number associated with this product. | 
**fulfilment_method** | **string** | Specifies whether this shipment has been fulfilled by the retailer (FBR) or by bol.com (FBB). | 
**latest_delivery_date** | [**\DateTime**](\DateTime.md) | Result of the date the order was placed combined with the delivery promise made by the seller. This field has been renamed from “PromisedDeliveryDate”. | [optional] 
**offer_condition** | **string** | Condition of the offer. | 
**offer_price** | **double** | Price for the entire product amount. This means the Item Price multiplied by the Quantity. | 
**offer_reference** | **string** | Value provided by seller through Offer API as ‘ReferenceCode’. | [optional] 
**order_item_id** | **string** | ID for the product (1 order can have multiple OrderItems). | 
**quantity** | **int** | Amount of the product being ordered. | 
**selected_delivery_window** | [**\Swagger\Client\Model\SelectedDeliveryWindow**](SelectedDeliveryWindow.md) |  | [optional] 
**title** | **string** | Title of the product as shown on the webshop. | 
**transaction_fee** | **double** | Fee of the transaction. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


