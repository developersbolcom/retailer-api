# DeliveryWindowsForInboundShipments_

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time_slots** | [**\Swagger\Client\Model\TimeSlot[]**](TimeSlot.md) | An available timeslot to be reserved for inbound shipments. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


