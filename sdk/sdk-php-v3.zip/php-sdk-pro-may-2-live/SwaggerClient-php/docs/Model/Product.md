# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**announced_quantity** | **int** | The number of announced items. | 
**bsku** | **string** | BSKU number associated with this product. | [optional] 
**ean** | **string** | EAN number associated with this product. | [optional] 
**received_quantity** | **int** | The number of received items. | [optional] 
**state** | **string** | The current state of the inbound product. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


