# PurchasableShippingLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**discount** | **float** | The discount of the item that has been sold. | 
**label_type** | **string** | The type of the label, representing the way an item is being transported. | 
**max_dimensions** | **string** | The dimensions of a package. | 
**max_weight** | **string** | The weight of a package. | 
**purchase_price** | **float** | The price the item has been bought for. | 
**retailer_price** | **float** | The price the item has been sold for. | 
**shipping_label_code** | **string** | An unique code referring to the shipping label. | 
**transporter_code** | **string** | A code representing the transporter which is being used for transportation. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


