# BulkCommissionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commissions** | [**\Swagger\Client\Model\Commission[]**](Commission.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


