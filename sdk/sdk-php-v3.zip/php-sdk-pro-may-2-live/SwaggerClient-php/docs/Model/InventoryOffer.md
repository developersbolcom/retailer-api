# InventoryOffer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bsku** | **string** | BSKU number associated with this product. | 
**ean** | **string** | EAN number associated with this product. | 
**nck_stock** | **int** | The stock that can&#39;t be sold (unsaleable) | 
**stock** | **int** | The stock that can be sold (saleable). | 
**title** | **string** | The product title. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


