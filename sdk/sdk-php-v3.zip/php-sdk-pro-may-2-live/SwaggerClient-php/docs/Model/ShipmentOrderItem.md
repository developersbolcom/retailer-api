# ShipmentOrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ean** | **string** | EAN number associated with this product. | 
**fulfilment_method** | **string** | Specifies whether this shipment has been fulfilled by the retailer (FBR) or by bol.com (FBB). | 
**latest_delivery_date** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format when the order was promised to be delivered. | 
**offer_condition** | **string** | Condition of the offer. | 
**offer_price** | **float** | Price for the entire product amount. This means the Item Price multiplied by the Quantity. | 
**offer_reference** | **string** | Value provided by seller through Offer API as ‘ReferenceCode’. | 
**order_date** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format when the order was placed. | 
**order_id** | **string** | The order id. | 
**order_item_id** | **string** | Item being sent. OrderItemID can be retrieved through the order request. | 
**quantity** | **int** | Amount of the product being ordered. | 
**selected_delivery_window** | [**\Swagger\Client\Model\SelectedDeliveryWindow**](SelectedDeliveryWindow.md) |  | [optional] 
**title** | **string** | The product title. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


