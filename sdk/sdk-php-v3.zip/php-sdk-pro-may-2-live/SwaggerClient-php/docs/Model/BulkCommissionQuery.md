# BulkCommissionQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | **string** | Condition of the offer. | [optional] 
**ean** | **string** | EAN number associated with this product. | 
**price** | **float** | The price of the product with a period as a decimal separator. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


