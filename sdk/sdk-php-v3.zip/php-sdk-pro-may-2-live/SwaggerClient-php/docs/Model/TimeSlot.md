# TimeSlot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**end** | [**\DateTime**](\DateTime.md) | The timeslot end date and time in ISO 8601 format. | 
**start** | [**\DateTime**](\DateTime.md) | The timeslot start date and time in ISO 8601 format. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


