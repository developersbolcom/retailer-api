# ProductLabelsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_labels** | [**\Swagger\Client\Model\ProductLabel[]**](ProductLabel.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


