# Inbounds

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inbounds** | [**\Swagger\Client\Model\Inbound[]**](Inbound.md) | An inbound shipment. | 
**total_count** | **int** | Number of total inbound shipments. | 
**total_page_count** | **int** | Total number of pages. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


