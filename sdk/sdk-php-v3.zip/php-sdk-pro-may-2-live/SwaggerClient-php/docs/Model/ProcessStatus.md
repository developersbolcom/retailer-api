# ProcessStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_timestamp** | [**\DateTime**](\DateTime.md) | Time of creation of the response. | 
**description** | **string** | Describes the action that is being processed. | 
**entity_id** | **string** | ID of the object being processed. E.g. in case of a shipment process-ID, you will receive the ID of the OrderItem being processed. | [optional] 
**error_message** | **string** | Shows error message if applicable. | [optional] 
**event_type** | **string** | Name of the requested action that is being processed. | 
**id** | **int** | ID of the process-status. | [optional] 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) | Lists available actions applicable to this endpoint. | 
**seller_id** | **int** | ID of the seller. | 
**status** | **string** | Status of the action being processed. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


