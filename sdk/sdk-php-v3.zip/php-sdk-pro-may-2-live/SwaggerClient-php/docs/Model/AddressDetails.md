# AddressDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_supplement** | **string** | Address supplement. | [optional] 
**city** | **string** | City name | 
**company** | **string** | Company name | [optional] 
**country_code** | **string** | Country code | 
**delivery_phone_number** | **string** | Delivery phone number. | [optional] 
**email** | **string** | Email address | 
**extra_address_information** | **string** | Extra information about the address. | [optional] 
**first_name** | **string** | First name | 
**house_number** | **string** | House number | 
**house_number_extended** | **string** | Extension on house number. | [optional] 
**salutation_code** | **string** |  | 
**street_name** | **string** | Street name | 
**sur_name** | **string** | Surname | 
**vat_number** | **string** | VAT number | [optional] 
**zip_code** | **string** | Zipcode | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


