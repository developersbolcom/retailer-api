# Commission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | **string** | Condition of the offer. | [optional] 
**ean** | **string** | EAN number associated with this product. | [optional] 
**fixed_amount** | **float** | Fixed fee. | 
**percentage** | **float** | Percentage of offer price. This percentage varies per product category. | 
**price** | **float** | The price of the product with a period as a decimal separator. | [optional] 
**reductions** | [**\Swagger\Client\Model\Reduction[]**](Reduction.md) |  | 
**total_cost** | **float** | Total applicable fee calculated based on the offer price provided. | [optional] 
**total_cost_without_reduction** | **float** | Total applicable fee calculated based on the offer price which would be in effect if you do not meet the maximum price criteria. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


