# Status

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_code** | **string** | If Published is set to N, this field will show the associated error code. | 
**error_message** | **string** | Explains the reason why this offer is not shown if Published is N. | 
**valid** | **bool** | Shows whether or not this offer is valid on the website. It is set to &#39;false&#39; by bol.com if any errors occur in this offer or if it is out of stock. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


