# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customer_details** | [**\Swagger\Client\Model\CustomerDetails**](CustomerDetails.md) |  | 
**date_time_order_placed** | [**\DateTime**](\DateTime.md) | The date/time in ISO 8601 format the order was placed. | [optional] 
**order_id** | **string** | The order id | 
**order_items** | [**\Swagger\Client\Model\OrderItem[]**](OrderItem.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


