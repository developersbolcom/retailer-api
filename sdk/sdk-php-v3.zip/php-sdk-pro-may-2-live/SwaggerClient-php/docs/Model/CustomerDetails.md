# CustomerDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_supplement** | **string** | Address supplement. | 
**city** | **string** | City name | 
**company** | **string** | Company name | 
**country_code** | **string** | Country code | 
**delivery_phone_number** | **string** | Delivery phone number. | 
**email** | **string** | Email address | 
**extra_address_information** | **string** | Extra information about the address. | 
**first_name** | **string** | First name | 
**house_number** | **string** | House number | 
**house_number_extended** | **string** | Extension on house number. | 
**salutation_code** | **string** |  | 
**street_name** | **string** | Street name | 
**surname** | **string** | Surname | 
**vat_number** | **string** | VAT number | 
**zip_code** | **string** | Zipcode | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


