# Inbound

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**announced_bsk_us** | **int** | The number of announced BSKU&#39;s. | 
**announced_quantity** | **int** | The number of announced items. | 
**creation_date** | [**\DateTime**](\DateTime.md) | The date the inbound shipment was created in ISO 8601 format. | [optional] 
**fbb_transporter** | [**\Swagger\Client\Model\Transporter**](Transporter.md) | Transporter for the inbound shipment. | 
**id** | **int** | A unique id for an inbound shipment. | 
**labelling_service** | **bool** | Indicates whether the inbound will be labeled by bol.com or not. | 
**products** | [**\Swagger\Client\Model\Product[]**](Product.md) | List of products. | 
**received_bsk_us** | **int** | The number of received BSKU&#39;s. | 
**received_quantity** | **int** | The number of received items. | 
**reference** | **string** | A user defined reference to identify the inbound shipment with. | 
**state** | **string** | The current state of the inbound shipment. | 
**state_transitions** | [**\Swagger\Client\Model\StateTransition[]**](StateTransition.md) | List of state transitions. | 
**time_slot** | [**\Swagger\Client\Model\TimeSlot**](TimeSlot.md) | The chosen timeslot for the inbound shipment. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


