# InboundRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fbb_transporter** | [**\Swagger\Client\Model\Transporter**](Transporter.md) | Transporter for the inbound shipment. | 
**labelling_service** | **bool** | Indicates whether the inbound will be labeled by bol.com or not. | 
**products** | [**\Swagger\Client\Model\Product[]**](Product.md) | List of products. | 
**reference** | **string** | A user defined reference to identify the inbound shipment with. | [optional] 
**time_slot** | [**\Swagger\Client\Model\TimeSlot**](TimeSlot.md) | The chosen timeslot for the inbound shipment. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


