# Swagger\Client\OrdersApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancelOrder**](OrdersApi.md#cancelOrder) | **PUT** /retailer/orders/{order-item-id}/cancellation | Cancel an order by order item id
[**getOrder**](OrdersApi.md#getOrder) | **GET** /retailer/orders/{order-id} | Get an order by order id
[**getOrders**](OrdersApi.md#getOrders) | **GET** /retailer/orders | Get all open orders
[**shipOrderItem**](OrdersApi.md#shipOrderItem) | **PUT** /retailer/orders/{order-item-id}/shipment | Ship order item


# **cancelOrder**
> \Swagger\Client\Model\ProcessStatus cancelOrder($order_item_id, $cancellation)

Cancel an order by order item id

This endpoint can be used to either confirm a cancellation request by the customer, or to cancel an order you yourself are unable to fulfil.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OrdersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$order_item_id = "order_item_id_example"; // string | The id of the order item to cancel.
$cancellation = new \Swagger\Client\Model\Cancellation(); // \Swagger\Client\Model\Cancellation | cancellation

try {
    $result = $apiInstance->cancelOrder($order_item_id, $cancellation);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrdersApi->cancelOrder: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_item_id** | **string**| The id of the order item to cancel. |
 **cancellation** | [**\Swagger\Client\Model\Cancellation**](../Model/Cancellation.md)| cancellation |

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOrder**
> \Swagger\Client\Model\Orders getOrder($order_id)

Get an order by order id

Gets an order by order id

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OrdersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$order_id = "order_id_example"; // string | The id of the order to get

try {
    $result = $apiInstance->getOrder($order_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrdersApi->getOrder: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_id** | **string**| The id of the order to get |

### Return type

[**\Swagger\Client\Model\Orders**](../Model/Orders.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOrders**
> \Swagger\Client\Model\Orders getOrders($page, $shipments_method)

Get all open orders

Gets a paginated list of all open orders sorted by date (descending).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OrdersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$page = 1; // int | The page to get
$shipments_method = "FBR"; // string | The shipments method to filter orders by

try {
    $result = $apiInstance->getOrders($page, $shipments_method);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrdersApi->getOrders: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| The page to get | [optional] [default to 1]
 **shipments_method** | **string**| The shipments method to filter orders by | [optional] [default to FBR]

### Return type

[**\Swagger\Client\Model\Orders**](../Model/Orders.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipOrderItem**
> \Swagger\Client\Model\ProcessStatus shipOrderItem($order_item_id, $shipment_request)

Ship order item

Ship a single order item within an order by providing shipping information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OrdersApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$order_item_id = "order_item_id_example"; // string | The order item being confirmed.
$shipment_request = new \Swagger\Client\Model\ShipmentRequest(); // \Swagger\Client\Model\ShipmentRequest | shipmentRequest

try {
    $result = $apiInstance->shipOrderItem($order_item_id, $shipment_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrdersApi->shipOrderItem: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_item_id** | **string**| The order item being confirmed. |
 **shipment_request** | [**\Swagger\Client\Model\ShipmentRequest**](../Model/ShipmentRequest.md)| shipmentRequest |

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

