# Swagger\Client\CommissionApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCommission**](CommissionApi.md#getCommission) | **GET** /retailer/commission/{ean} | Get all commissions and reductions by EAN per single EAN
[**getCommissions**](CommissionApi.md#getCommissions) | **POST** /retailer/commission | Get all commissions and reductions by EAN in bulk


# **getCommission**
> \Swagger\Client\Model\Commission getCommission($ean, $condition, $price)

Get all commissions and reductions by EAN per single EAN

Commissions can be filtered by condition, which defaults to NEW. If price is provided, the exact commission amount will also be calculated.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CommissionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$ean = "ean_example"; // string | EAN number associated with this product.
$condition = "NEW"; // string | Condition of the offer.
$price = 8.14; // float | The price of the product with a period as a decimal separator.

try {
    $result = $apiInstance->getCommission($ean, $condition, $price);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CommissionApi->getCommission: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ean** | **string**| EAN number associated with this product. |
 **condition** | **string**| Condition of the offer. | [optional] [default to NEW]
 **price** | **float**| The price of the product with a period as a decimal separator. | [optional]

### Return type

[**\Swagger\Client\Model\Commission**](../Model/Commission.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getCommissions**
> \Swagger\Client\Model\BulkCommissionResponse getCommissions($request)

Get all commissions and reductions by EAN in bulk

Gets all commissions and possible reductions by EAN, condition, and optionally price. No more than 100 EANs can be sent in a single request.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CommissionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$request = new \Swagger\Client\Model\BulkCommissionRequest(); // \Swagger\Client\Model\BulkCommissionRequest | request

try {
    $result = $apiInstance->getCommissions($request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CommissionApi->getCommissions: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **request** | [**\Swagger\Client\Model\BulkCommissionRequest**](../Model/BulkCommissionRequest.md)| request |

### Return type

[**\Swagger\Client\Model\BulkCommissionResponse**](../Model/BulkCommissionResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

