# Swagger\Client\TransportsApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addTransportInformationByTransportId**](TransportsApi.md#addTransportInformationByTransportId) | **PUT** /retailer/transports/{transport-id} | Add transport information by transport id
[**getShippingLabelUsingGET**](TransportsApi.md#getShippingLabelUsingGET) | **GET** /retailer/transports/{transport-id}/shipping-label | Get shipping label by transport id


# **addTransportInformationByTransportId**
> \Swagger\Client\Model\ProcessStatus addTransportInformationByTransportId($transport_id, $change_transport)

Add transport information by transport id

Add information to an existing transport. The transport id is part of the shipment. You can retrieve the transport id through the GET shipment list request.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TransportsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$transport_id = 789; // int | The transport id
$change_transport = new \Swagger\Client\Model\ChangeTransportRequest(); // \Swagger\Client\Model\ChangeTransportRequest | The change transport requested by the user.

try {
    $result = $apiInstance->addTransportInformationByTransportId($transport_id, $change_transport);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TransportsApi->addTransportInformationByTransportId: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **transport_id** | **int**| The transport id |
 **change_transport** | [**\Swagger\Client\Model\ChangeTransportRequest**](../Model/ChangeTransportRequest.md)| The change transport requested by the user. | [optional]

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getShippingLabelUsingGET**
> string getShippingLabelUsingGET($transport_id)

Get shipping label by transport id

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TransportsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$transport_id = 789; // int | The transport id

try {
    $result = $apiInstance->getShippingLabelUsingGET($transport_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TransportsApi->getShippingLabelUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **transport_id** | **int**| The transport id |

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/pdf

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

