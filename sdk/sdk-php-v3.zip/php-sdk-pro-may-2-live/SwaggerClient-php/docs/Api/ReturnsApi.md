# Swagger\Client\ReturnsApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**handleReturn**](ReturnsApi.md#handleReturn) | **GET** /retailer/returns | Get all returns
[**handleReturn1**](ReturnsApi.md#handleReturn1) | **PUT** /retailer/returns/{return-number} | Handle an open return


# **handleReturn**
> \Swagger\Client\Model\ReturnsResponse handleReturn($page, $handled, $shipments_method)

Get all returns

Retrieves all returns, which are sorted by date in descending order.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ReturnsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$page = 1; // int | The page to get
$handled = false; // bool | The status of the returns you wish to see, shows either handled or unhandled returns
$shipments_method = "FBR"; // string | The shipments method to filter orders by

try {
    $result = $apiInstance->handleReturn($page, $handled, $shipments_method);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ReturnsApi->handleReturn: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| The page to get | [optional] [default to 1]
 **handled** | **bool**| The status of the returns you wish to see, shows either handled or unhandled returns | [optional] [default to false]
 **shipments_method** | **string**| The shipments method to filter orders by | [optional] [default to FBR]

### Return type

[**\Swagger\Client\Model\ReturnsResponse**](../Model/ReturnsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **handleReturn1**
> \Swagger\Client\Model\ProcessStatus handleReturn1($return_number, $handling_result)

Handle an open return

Allows the user to handle a return by setting a new handling result for it after receiving the returned item(s).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ReturnsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$return_number = 56; // int | The return number.
$handling_result = new \Swagger\Client\Model\ReturnRequest(); // \Swagger\Client\Model\ReturnRequest | The handling result requested by the user.

try {
    $result = $apiInstance->handleReturn1($return_number, $handling_result);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ReturnsApi->handleReturn1: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **return_number** | **int**| The return number. |
 **handling_result** | [**\Swagger\Client\Model\ReturnRequest**](../Model/ReturnRequest.md)| The handling result requested by the user. | [optional]

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

