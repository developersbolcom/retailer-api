# Swagger\Client\ProcessStatusApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getProcessStatus**](ProcessStatusApi.md#getProcessStatus) | **GET** /retailer/process-status/{process-status-id} | Get the status of an asynchronous process by id


# **getProcessStatus**
> \Swagger\Client\Model\ProcessStatus getProcessStatus($process_status_id)

Get the status of an asynchronous process by id

Retrieve a specific process-status, which shows information regarding a previously executed POST- or PUT-request. All PUT- and POST-requests on the other endpoints will supply a process-status-ID in the related response. You can use this ID to retrieve a status by using the endpoint below.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProcessStatusApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$process_status_id = 789; // int | The ID of the process-status being requested. This ID is supplied in every response to a PUT/POST request on the other endpoints.

try {
    $result = $apiInstance->getProcessStatus($process_status_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProcessStatusApi->getProcessStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **process_status_id** | **int**| The ID of the process-status being requested. This ID is supplied in every response to a PUT/POST request on the other endpoints. |

### Return type

[**\Swagger\Client\Model\ProcessStatus**](../Model/ProcessStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

