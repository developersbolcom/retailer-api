# Swagger\Client\ShippingLabelsApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getShippingLabels**](ShippingLabelsApi.md#getShippingLabels) | **GET** /retailer/purchasable-shippinglabels/{order-item-id} | Get purchasable shipping labels by order item id


# **getShippingLabels**
> \Swagger\Client\Model\PurchasableShippingLabelsResponse getShippingLabels($order_item_id)

Get purchasable shipping labels by order item id

Retrieves all available shipping labels based on the supplied order item.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ShippingLabelsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$order_item_id = "order_item_id_example"; // string | The orderItemId of the order to get purchasable shipping labels from

try {
    $result = $apiInstance->getShippingLabels($order_item_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingLabelsApi->getShippingLabels: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_item_id** | **string**| The orderItemId of the order to get purchasable shipping labels from |

### Return type

[**\Swagger\Client\Model\PurchasableShippingLabelsResponse**](../Model/PurchasableShippingLabelsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

