# Swagger\Client\ShipmentsApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getShipment**](ShipmentsApi.md#getShipment) | **GET** /retailer/shipments/{shipment-id} | Get a shipment by shipment id
[**getShipments**](ShipmentsApi.md#getShipments) | **GET** /retailer/shipments | Get shipment list


# **getShipment**
> \Swagger\Client\Model\Shipment getShipment($shipment_id)

Get a shipment by shipment id

Retrieve a single shipment by its corresponding id.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ShipmentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$shipment_id = 789; // int | The id of the shipment

try {
    $result = $apiInstance->getShipment($shipment_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentsApi->getShipment: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment_id** | **int**| The id of the shipment |

### Return type

[**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getShipments**
> \Swagger\Client\Model\ShipmentResponse getShipments($page, $shipments_method, $order_id)

Get shipment list

With this endpoint you are able to retrieve your shipments. The shipments will be sorted by date in descending order.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ShipmentsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$page = 1; // int | The page number to get
$shipments_method = "FBR"; // string | The shipments method. FBR means Fulfilment By Retailer and FBB means Fulfilment By Bol
$order_id = "order_id_example"; // string | The id of the order to get shipment information for

try {
    $result = $apiInstance->getShipments($page, $shipments_method, $order_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentsApi->getShipments: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **int**| The page number to get | [optional] [default to 1]
 **shipments_method** | **string**| The shipments method. FBR means Fulfilment By Retailer and FBB means Fulfilment By Bol | [optional] [default to FBR]
 **order_id** | **string**| The id of the order to get shipment information for | [optional]

### Return type

[**\Swagger\Client\Model\ShipmentResponse**](../Model/ShipmentResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

