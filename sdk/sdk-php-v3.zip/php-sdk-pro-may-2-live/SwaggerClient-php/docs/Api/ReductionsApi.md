# Swagger\Client\ReductionsApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getLatestReductionsFilename**](ReductionsApi.md#getLatestReductionsFilename) | **GET** /retailer/reductions/latest | Get latest reductions filename
[**getReductions**](ReductionsApi.md#getReductions) | **GET** /retailer/reductions | Get reductions list


# **getLatestReductionsFilename**
> string getLatestReductionsFilename()

Get latest reductions filename

This endpoint below will return a filename of the latest reductions list. The response from this endpoint can be compared to the response header that was given back from the Get Reductions List endpoint

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ReductionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getLatestReductionsFilename();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ReductionsApi->getLatestReductionsFilename: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+csv

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getReductions**
> getReductions()

Get reductions list

This endpoint will return a list EAN’s that are eligible for reductions on the commission fee.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ReductionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->getReductions();
} catch (Exception $e) {
    echo 'Exception when calling ReductionsApi->getReductions: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+csv

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

