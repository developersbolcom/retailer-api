# Swagger\Client\InvoicesApi

All URIs are relative to *https://merchant.services.bol.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getInvoice**](InvoicesApi.md#getInvoice) | **GET** /retailer/invoices/{invoice-id} | Get an invoice by invoice id
[**getInvoiceSpecification**](InvoicesApi.md#getInvoiceSpecification) | **GET** /retailer/invoices/{invoice-id}/specification | Get an invoice specification by invoice id
[**getInvoices**](InvoicesApi.md#getInvoices) | **GET** /retailer/invoices | Get all invoices


# **getInvoice**
> string getInvoice($invoice_id)

Get an invoice by invoice id

Gets an invoice by invoice id. The available media types differ per invoice and are listed within the response from the ‘GET all invoices’ call. Note, the media types listed in the response must be given in our standard API format.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InvoicesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$invoice_id = 789; // int | The id of the invoice

try {
    $result = $apiInstance->getInvoice($invoice_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InvoicesApi->getInvoice: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **invoice_id** | **int**| The id of the invoice |

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml, application/vnd.retailer.v3+pdf

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInvoiceSpecification**
> string getInvoiceSpecification($invoice_id, $page)

Get an invoice specification by invoice id

Gets an invoice specification for an invoice with a paginated list of its transactions. The available media types differ per invoice specification and are listed within the response from the ‘GET all invoices’ call. Note, the media types listed in the response must be given in our standard API format.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InvoicesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$invoice_id = 789; // int | The id of the invoice
$page = 56; // int | The page to get

try {
    $result = $apiInstance->getInvoiceSpecification($invoice_id, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InvoicesApi->getInvoiceSpecification: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **invoice_id** | **int**| The id of the invoice |
 **page** | **int**| The page to get | [optional]

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml, application/vnd.retailer.v3+pdf, application/vnd.retailer.v3+openxmlformats-officedocument.spreadsheetml.sheet

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getInvoices**
> string getInvoices($period)

Get all invoices

Gets a list of invoices, by default from the past 4 weeks. The optional period parameter can be used to retrieve invoices from a specific date range in the past. Invoices and their specifications can be downloaded separately in different media formats with the 'GET an invoice by id’ and the 'GET an invoice specification by id’ calls. The available media types differ per invoice and are listed per invoice within the response. Note, the media types listed in the response must be given in our standard API format.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\InvoicesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$period = "period_example"; // string | The period to get invoices for. The period parameter has to comply to the ISO 6801 standard. The format of this standard is as follows: yyyy-mm-dd/yyyy-mm-dd. The period can be no longer than 32 days. The list of invoices is sorted on date in descending order.

try {
    $result = $apiInstance->getInvoices($period);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InvoicesApi->getInvoices: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **period** | **string**| The period to get invoices for. The period parameter has to comply to the ISO 6801 standard. The format of this standard is as follows: yyyy-mm-dd/yyyy-mm-dd. The period can be no longer than 32 days. The list of invoices is sorted on date in descending order. | [optional]

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/vnd.retailer.v3+json, application/vnd.retailer.v3+xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

